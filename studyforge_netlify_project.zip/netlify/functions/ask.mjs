// Netlify Function: keeps the Gemini API key on the server.
export default async (req) => {
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json; charset=utf-8",
  };

  if (req.method === "OPTIONS") {
    return new Response("", { status: 204, headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return Response.json({ error: "Gunakan metode POST." }, { status: 405, headers: corsHeaders });
  }

  try {
    const apiKey = Netlify.env.get("GEMINI_API_KEY");
    if (!apiKey) {
      return Response.json(
        { error: "Server belum dikonfigurasi. Tambahkan GEMINI_API_KEY di pengaturan Netlify." },
        { status: 500, headers: corsHeaders }
      );
    }

    const body = await req.json();
    const material = typeof body.material === "string" ? body.material.slice(0, 90000) : "";
    const youtubeUrl = typeof body.youtubeUrl === "string" ? body.youtubeUrl.trim() : "";
    const prompt = typeof body.prompt === "string" ? body.prompt.slice(0, 12000) : "";

    if (!material.trim() && !youtubeUrl) {
      return Response.json({ error: "Masukkan materi atau link YouTube." }, { status: 400, headers: corsHeaders });
    }

    const parts = [];
    if (material.trim()) parts.push({ text: "MATERI DARI PENGGUNA:\n" + material });
    if (youtubeUrl) {
      let parsed;
      try { parsed = new URL(youtubeUrl); } catch {
        return Response.json({ error: "Link YouTube tidak valid." }, { status: 400, headers: corsHeaders });
      }
      const host = parsed.hostname.toLowerCase();
      const validHost = host === "youtube.com" || host.endsWith(".youtube.com") || host === "youtu.be";
      if (parsed.protocol !== "https:" || !validHost) {
        return Response.json({ error: "Masukkan link HTTPS dari YouTube." }, { status: 400, headers: corsHeaders });
      }
      parts.push({ file_data: { file_uri: youtubeUrl } });
    }
    parts.push({ text: prompt || "Bantu pelajari materi ini dengan bahasa Indonesia." });

    const upstream = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
      {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
        body: JSON.stringify({
          contents: [{ parts }],
          generationConfig: { temperature: 0.4, maxOutputTokens: 8192 }
        })
      }
    );

    const result = await upstream.json();
    if (!upstream.ok) {
      const detail = result?.error?.message || `Layanan AI gagal (HTTP ${upstream.status}).`;
      return Response.json({ error: detail }, { status: upstream.status, headers: corsHeaders });
    }
    const text = (result.candidates || [])
      .flatMap(candidate => candidate.content?.parts || [])
      .map(part => part.text || "")
      .filter(Boolean)
      .join("\n")
      .trim();

    if (!text) {
      return Response.json({ error: "AI tidak menghasilkan teks. Coba lagi." }, { status: 502, headers: corsHeaders });
    }
    return Response.json({ text }, { status: 200, headers: corsHeaders });
  } catch (error) {
    return Response.json(
      { error: error?.message || "Terjadi kesalahan pada server." },
      { status: 500, headers: corsHeaders }
    );
  }
};
