STUDYFORGE AI GAMER EDITION — NETLIFY BACKEND

Isi:
- index.html: web StudyForge
- netlify/functions/ask.mjs: backend yang menyimpan penggunaan Gemini API di server
- netlify.toml: konfigurasi Netlify Functions

LANGKAH UMUM:
1. Upload semua isi folder proyek ke sebuah repository GitHub.
2. Di Netlify, pilih Add new site / Import an existing project, lalu hubungkan repository.
3. Build command boleh dikosongkan; publish directory: .
4. Setelah deploy, buka Site configuration > Environment variables (atau Project configuration > Environment variables).
5. Tambahkan:
   Key: GEMINI_API_KEY
   Value: [API key Gemini milikmu]
6. Simpan, lalu lakukan redeploy agar fungsi memakai konfigurasi baru.
7. Tes web melalui URL Netlify. Fungsi backend ada di /.netlify/functions/ask.

KEAMANAN:
- Jangan taruh API key di index.html atau repository.
- Jangan bagikan API key ke siapa pun.
- Tambahkan batas penggunaan/rate limiting dan autentikasi sebelum situs dipublikasikan luas; tanpa itu orang lain bisa memakai kuota API jika endpoint publik.
- Model API yang dipakai pada starter ini adalah gemini-2.5-flash. Jika Google mengubah ketersediaan model atau akses YouTube, sesuaikan di ask.mjs.
- Pemrosesan YouTube tergantung dukungan API, akses video, dan kuota; tidak semua tautan bisa diproses.
